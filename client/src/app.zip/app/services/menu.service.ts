
export class MenuService{
private menuStt = false;

enableBtn(){
this.menuStt = true;
}

disableBtn(){
this.menuStt = false;
}

}